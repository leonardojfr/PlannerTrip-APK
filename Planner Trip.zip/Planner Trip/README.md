# PlannerTrip

## Descrição da aplicação

O PlannerTrip é uma aplicação móvel desenvolvida para Android que funciona como um diário de bordo digital, permitindo ao utilizador organizar e guardar informações sobre as suas viagens num único local. A aplicação foi pensada para facilitar o registo das experiências de cada viagem, permitindo guardar notas, fotografias e acompanhar as despesas realizadas.

Através da aplicação, é possível criar viagens, indicando o nome, o destino, as datas de início e fim e a moeda principal utilizada. Dentro de cada viagem, o utilizador pode adicionar, editar e eliminar notas, onde pode registar os momentos e experiências mais importantes, bem como associar fotografias. Também é possível registar despesas, indicando a respetiva descrição, valor, moeda e data, permitindo acompanhar o dinheiro gasto ao longo da viagem.

## Funcionalidades adicionais

Para além das funcionalidades principais, foram desenvolvidas algumas funcionalidades adicionais com o objetivo de tornar a aplicação mais completa e prática. Uma delas é a possibilidade de adicionar fotografias às notas, recorrendo diretamente à câmara do dispositivo ou escolhendo imagens da galeria. Foi também implementado um sistema de reconhecimento de voz, que permite ao utilizador ditar o conteúdo das suas notas, sem ter de escrever todo o texto manualmente.

Outra funcionalidade adicional é a conversão de moedas, que permite registar despesas em moedas diferentes da moeda principal da viagem. Para isso, a aplicação utiliza a API Frankfurter, através da qual obtém as taxas de câmbio necessárias para converter os valores e calcular o total das despesas na moeda base. As últimas taxas obtidas são guardadas localmente, permitindo continuar a utilizar os valores anteriormente disponíveis mesmo quando não existe ligação à Internet.

## Tecnologias e armazenamento de dados

A aplicação foi desenvolvida em Java, utilizando o Android Studio, com as interfaces gráficas construídas através de ficheiros XML. Para o armazenamento dos dados foi utilizado SQLite, através da classe SQLiteOpenHelper. Esta escolha deveu-se também ao facto de esta tecnologia ter sido abordada e trabalhada nas aulas, permitindo aplicar os conhecimentos adquiridos ao longo da unidade curricular.

A base de dados é criada localmente no dispositivo e está organizada em quatro tabelas principais: viagens, notas, despesas e taxas de câmbio. A tabela das viagens guarda as informações gerais de cada viagem. As tabelas das notas e das despesas estão relacionadas com a tabela das viagens através do identificador da respetiva viagem, permitindo associar vários registos à mesma viagem. Quando uma viagem é eliminada, as respetivas notas e despesas também são eliminadas automaticamente através das relações de chave estrangeira e da opção ON DELETE CASCADE.

A tabela das taxas guarda a última taxa de câmbio conhecida para cada par de moedas. Desta forma, a aplicação consegue aproveitar os valores anteriormente obtidos quando não existe acesso à Internet. As fotografias são associadas às notas através da respetiva URI, em vez de serem guardadas diretamente na base de dados.

## Decisões de implementação

Durante o desenvolvimento, procurei organizar o código de forma a separar as diferentes responsabilidades da aplicação. Para isso, foram utilizados três packages principais: 'data', onde se encontram as classes responsáveis pelos dados e pela comunicação com a API; 'ui', que contém os diferentes ecrãs e a respetiva lógica de interação; e 'util', onde estão reunidas funções auxiliares utilizadas em diferentes partes da aplicação.

Outra decisão importante foi utilizar uma base de dados local, permitindo que a informação das viagens, notas e despesas permaneça guardada no dispositivo, sem depender constantemente de uma ligação à Internet. No caso da conversão de moedas, os pedidos à API são realizados numa thread separada, evitando bloquear a interface enquanto a aplicação aguarda uma resposta.

## Dificuldades encontradas

Ao longo do desenvolvimento surgiram algumas dificuldades, principalmente na integração da API de câmbio, na implementação da câmara e da galeria e no desenvolvimento do sistema de reconhecimento de voz.

A integração da API de câmbio exigiu algum trabalho para conseguir obter corretamente as taxas e utilizar os valores recebidos nos cálculos das despesas. Na parte das fotografias, a principal dificuldade esteve em conseguir integrar a câmara e a galeria com a aplicação e garantir que as imagens selecionadas ou capturadas ficavam corretamente associadas às notas. Relativamente ao reconhecimento de voz, foi necessário trabalhar com os mecanismos disponibilizados pelo Android para obter o texto ditado pelo utilizador e inseri-lo no campo correspondente.

Apesar destas dificuldades, consegui implementar todas estas funcionalidades e deixá-las a funcionar corretamente.

## Compilação, execução e testes

Para abrir o projeto, basta abrir o Android Studio, selecionar a opção de abrir um projeto existente e escolher a pasta principal 'PlannerTrip'. Depois de o projeto ser carregado, é necessário aguardar pela sincronização do Gradle, para que as dependências e configurações sejam reconhecidas corretamente.

Para compilar a aplicação e executar a aplicação, basta selecionar um emulador ou um dispositivo Android ligado ao computador e carregar no botão Run do Android Studio.

Os testes foram realizados tanto num emulador como num telemóvel físico. Durante os testes, foram verificadas as funcionalidades de criação, edição e eliminação de viagens, notas e despesas, bem como a associação de fotografias, o reconhecimento de voz e a conversão de moedas. Foi também verificado o comportamento da aplicação quando não existe ligação à Internet, nomeadamente a utilização das últimas taxas de câmbio guardadas.

No geral, os testes permitiram confirmar que as funcionalidades implementadas estão a funcionar corretamente nos dispositivos utilizados.

## Utilização de ferramentas externas e inteligência artificial

Durante o desenvolvimento do projeto, foi utilizada ajuda externa como o Claude AI e o Gemini, como apoio à resolução de algumas dificuldades encontradas ao longo da implementação. Esta ajuda foi especialmente útil na integração da API de câmbio, na implementação da câmara e da galeria e no desenvolvimento do sistema de reconhecimento de voz. Foi também utilizada como apoio na organização e correção de erros deste ficheiro README.md.

A utilização desta ferramenta teve como principal objetivo esclarecer dúvidas, compreender melhor determinados mecanismos e encontrar soluções para os problemas que foram surgindo durante o desenvolvimento. As sugestões obtidas foram analisadas e adaptadas às necessidades do projeto.
